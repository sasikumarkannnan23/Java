package myfirst;

public class Welcome {
		public String sayHi() {
			return "Hi";
		}
}

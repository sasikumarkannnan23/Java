package tight;

public class TmainClass {

	public static void main(String[] args) {
		Traveller t = new Traveller(new Bike());
		t.startJourney();

	}

}

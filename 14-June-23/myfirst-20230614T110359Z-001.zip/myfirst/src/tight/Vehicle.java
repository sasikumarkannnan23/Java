package tight;

public interface Vehicle {
	public void move();
}

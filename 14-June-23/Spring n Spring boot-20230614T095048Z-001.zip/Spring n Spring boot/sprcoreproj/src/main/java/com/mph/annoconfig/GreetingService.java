package com.mph.annoconfig;

public interface GreetingService {
	public void sayHi();
}

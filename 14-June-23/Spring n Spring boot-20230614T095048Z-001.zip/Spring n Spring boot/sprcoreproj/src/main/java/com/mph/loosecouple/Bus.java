package com.extra.loosecouple;

public class Bus implements Vehicle {
	public void move() {
		System.out.println("Bus is moving...");
	}

}

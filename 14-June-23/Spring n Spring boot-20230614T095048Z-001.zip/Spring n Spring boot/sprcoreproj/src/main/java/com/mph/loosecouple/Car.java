package com.extra.loosecouple;

public class Car implements Vehicle{
	public void move() {
		System.out.println("Car is moving...");
	}

}

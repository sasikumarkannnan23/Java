package com.mph.javaconfig;

public interface GreetingService {
	public void sayHi();
}

package com.extra.loosecouple;
public interface Vehicle {
	public void move();
}

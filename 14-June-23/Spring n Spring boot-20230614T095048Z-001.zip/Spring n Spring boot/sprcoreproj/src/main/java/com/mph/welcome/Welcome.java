package com.mph.welcome;

public class Welcome {
	
	public String sayWelcome()
	{
		return "Welcome to Spring Core";
	}

}

package com.extra.tightcouple;

public class Car {
	public void move() {
		System.out.println("Car is moving...");
	}

}

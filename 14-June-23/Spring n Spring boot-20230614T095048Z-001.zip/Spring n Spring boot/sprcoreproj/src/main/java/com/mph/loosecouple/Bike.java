package com.extra.loosecouple;

public class Bike implements Vehicle{
	public void move() {
		System.out.println("Bike is moving...");
	}

}

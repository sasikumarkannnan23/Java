package com.mph.inher;

public interface Vehicle {
	  void start();
}

package com.mph.xmlconfig;

public interface GreetingService {
	public void sayHi();
}

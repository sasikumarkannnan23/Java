package com.extra.tightcouple;

public class Client {

	public static void main(String[] args) {
		Traveler  traveler = new Traveler();
		traveler.startJourney();
	}

}
